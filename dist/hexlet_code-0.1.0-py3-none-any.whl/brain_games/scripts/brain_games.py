#!/usr/bin/env python3
"""Project One. Start script."""

from brain_games import cli


def main():
    """Run welcom function."""
    cli.welcome_user()


if __name__ == '__main__':
    main()
