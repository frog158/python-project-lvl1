#!/usr/bin/env python3
"""Project One. Brain even."""

from brain_games import even


def main():
    """Main function."""
    even.start_game()


if __name__ == '__main__':
    main()
