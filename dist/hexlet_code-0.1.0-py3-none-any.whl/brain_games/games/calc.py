# -*- coding:utf-8 -*-

"""Calc game."""


from random import randint
from brain_games.games.games_engine import start_engine


def start_game():
    i = 1
    list_of_question = []
    while i <= 3:
        answer = 0
        question = '{0} {2} {1}'
        x1 = randint(1, 100)
        x2 = randint(1, 100)
        operator = randint(1, 3)
        if operator == 1:
            operator_string = '+'
            answer = x1 + x2
        elif operator == 2:
            operator_string = '-'
            answer = x1 - x2
        else:
            operator_string = "*"
            answer = x1 * x2
        question = question.format(str(x1), str(x2), operator_string)
        list_of_question.append((question, str(answer)))
        i += 1
    start_engine(list_of_question)
    
            


