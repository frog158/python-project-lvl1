# -*- coding:utf-8 -*-

"""Script examples."""

NAME = 'games_engine'